using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace myaspnetapp.Pages;

public class IndexModel : PageModel
{
    
}
