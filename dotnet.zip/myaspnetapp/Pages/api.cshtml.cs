using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace myaspnetapp.Pages
{
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    [IgnoreAntiforgeryToken]
    public class ApiModel : PageModel
    {
        [BindProperty]
        public string Symbol { get; set; }

        public IActionResult OnPost()
        {
            return new JsonResult(new { symbol = Symbol });
        }
    }
}
